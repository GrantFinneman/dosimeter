#!/bin/bash

#imagej 6MV/1x3.dcm plotting3.ijm & 
#imagej 6MV/3x3.dcm plotting3.ijm & 
#imagej 6MV/3x1.dcm plotting3.ijm & 
#imagej 6MV/2x2.dcm plotting3.ijm & 
#imagej 6MV/2x4.dcm plotting3.ijm & 
#imagej 6MV/4x2.dcm plotting3.ijm & 
#imagej 6MV/5x5.dcm plotting3.ijm & 
imagej 6MV/1x3.dcm plotting4.ijm & 
imagej 6MV/3x3.dcm plotting4.ijm & 
imagej 6MV/3x1.dcm plotting4.ijm & 
imagej 6MV/2x2.dcm plotting4.ijm & 
imagej 6MV/2x4.dcm plotting4.ijm & 
imagej 6MV/4x2.dcm plotting4.ijm & 
imagej 6MV/5x5.dcm plotting4.ijm 

